class Errors(Exception):
    pass

class MinAgeError(Errors):
    pass

class MaxAgeERoor(Errors):
    pass

class GenderError(Errors):
    pass